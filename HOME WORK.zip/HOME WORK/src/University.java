public class University {
    private String аты ;
    private int жашы;

    public String getАты() {
        return аты;
    }

    public int getЖашы() {
        return жашы;
    }

    public void setАты(String аты) {
        this.аты = аты;
    }

    public void setЖашы(int жашы) {
        this.жашы = жашы;
    }

    @Override
    public String toString() {
        return "University{" + "аты = " + аты  + " жашы = " + жашы + " } \n ";
    }
}