public class Car {
    private String марка;
    private int цена;

    public String getМарка() {
        return марка;
    }

    public void setМарка(String марка) {
        this.марка = марка;
    }

    public int getЦена() {
        return цена;
    }

    public void setЦена(int цена) {
        this.цена = цена;
    }

    @Override
    public String toString() {
        return "Car{" + "марка=" + марка  + ", цена=" + цена + "}\n";
    }
}
