public class Person {
    private String аты;
    private String фамиля;
    private double датаРождение;

    public String getАты() {
        return аты;
    }

    public void setАты(String аты) {
        this.аты = аты;
    }

    public String getФамиля() {
        return фамиля;
    }

    public void setФамиля(String фамиля) {
        this.фамиля = фамиля;
    }

    public double getДатаРождение() {
        return датаРождение;
    }

    public void setДатаРождение(double датаРождение) {
        this.датаРождение = датаРождение;
    }

    @Override
    public String toString() {
        return "Person{" + "аты=" + аты + ", фамилясы=" + фамиля +  ", дата рождение=" + датаРождение + "}\n";
    }
}
