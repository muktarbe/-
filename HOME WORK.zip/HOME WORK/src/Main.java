import java.nio.file.attribute.UserDefinedFileAttributeView;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        University aa = new University();
        aa.setАты(" Кандыбек ");
        aa.setЖашы(18);
        University ss  = new University();
        ss.setАты(" Залкар ");
        ss.setЖашы(17);
        University dd = new University();
        dd.setАты(" Муктар ");
        dd.setЖашы(16);
        University [] university = {aa,ss,dd};
        System.out.println(Arrays.toString(university));
        System.out.println("<------------------------------------->");
        School school = new School();
        school.setНазваниеШколы("Чынгыз Айтматов");
        school.setСкалькаУчителей(50);
        school.setСкалькаУчеников(1000);
        School school1 = new School();
        school1.setНазваниеШколы(" Тоголок Малдо ");
        school1.setСкалькаУчителей(25);
        school1.setСкалькаУчеников(500);
        School school2 = new School();
        school2.setНазваниеШколы("Бубусара Бейшаналиева");
        school2.setСкалькаУчителей(10);
        school2.setСкалькаУчеников(100);
        School [] a = {school ,school1,school2,};
        System.out.println(Arrays.toString(a));
        System.out.println("<------------------------------------->");
        Car car1 = new Car();
        car1.setМарка("Audi");
        car1.setЦена(10000);
        Car car2 = new Car();
        car2.setМарка("Porsche");
        car2.setЦена(100000);
        Car car3 = new Car();
        car3.setМарка("Hyundai");
        car3.setЦена(100000);
        Car [] h = {car1,car2,car3};
        System.out.println(Arrays.toString(h));
        System.out.println("<------------------------------------->");
        Person person1 = new Person();
        person1.setАты("Кандыбен");
        person1.setФамиля("Исаев");
        person1.setДатаРождение(15.07);
        Person person2 = new Person();
        person2.setАты("Айчурок");
        person2.setФамиля("Элебесова");
        person2.setДатаРождение(07.07);
        Person person3 = new Person();
        person3.setАты("Муктарбек");
        person3.setФамиля("Нурпазыл уулу");
        person3.setДатаРождение(23.09);
        Person [] q = {person1,person2,person3};
        System.out.println(Arrays.toString(q));
    }
}
