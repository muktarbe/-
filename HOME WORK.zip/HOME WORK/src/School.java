public class School {
    private  String названиеШколы;
    private  int скалькаУчителей;
    private  int скалькаУчеников;

    public String getНазваниеШколы() {
        return названиеШколы;
    }

    public void setНазваниеШколы(String названиеШколы) {
        this.названиеШколы = названиеШколы;
    }

    public int getСкалькаУчителей() {
        return скалькаУчителей;
    }

    public void setСкалькаУчителей(int скалькаУчителей) {
        this.скалькаУчителей = скалькаУчителей;
    }

    public int getСкалькаУчеников() {
        return скалькаУчеников;
    }

    public void setСкалькаУчеников(int скалькаУчеников) {
        this.скалькаУчеников = скалькаУчеников;
    }

    @Override
    public String toString() {
        return "School{" + "название школы=" + названиеШколы  + ", сколька учителей=" +
                скалькаУчителей + ", сколька учеников=" + скалькаУчеников + " } \n";
    }
}
